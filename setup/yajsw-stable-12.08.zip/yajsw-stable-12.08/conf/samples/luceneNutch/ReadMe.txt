Some configurations which are used in conjunction with the scripts for running nutch.
These scripts show how YAJSW can be used within groovy scripts to drive a job workflow