yajsw-stable-12.08

    * Bug: Unix supplemental groups
    * Bug: setting jna_tmp has no effect
    * Change: update to jna-4.2.2 + aix64 lib

For those still using yajsw-stable-11.08 it is recommended to update to this release.